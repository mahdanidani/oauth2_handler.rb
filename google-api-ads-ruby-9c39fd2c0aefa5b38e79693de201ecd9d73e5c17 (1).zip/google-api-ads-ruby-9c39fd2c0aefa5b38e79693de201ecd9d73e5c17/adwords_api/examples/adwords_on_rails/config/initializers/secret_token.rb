# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AdwordsOnRails::Application.config.secret_token = 'b20bd3d29512f3f742e244b70bea74f9e11822c7c3c3ba512ea85b497e42901b863562a792d8394acd10c4787792552e4c4111f93e1cf7b3110bec9c0ce91153'
