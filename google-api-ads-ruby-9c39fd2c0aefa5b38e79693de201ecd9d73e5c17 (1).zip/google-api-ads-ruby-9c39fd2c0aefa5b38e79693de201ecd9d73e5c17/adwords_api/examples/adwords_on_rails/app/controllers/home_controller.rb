class HomeController < ApplicationController

  def index()
    @selected_account = selected_account
  end
end
