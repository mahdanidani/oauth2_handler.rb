module GoogleAdsSavon

  # Base class for GoogleAdsSavon errors.
  class Error < RuntimeError; end

end
