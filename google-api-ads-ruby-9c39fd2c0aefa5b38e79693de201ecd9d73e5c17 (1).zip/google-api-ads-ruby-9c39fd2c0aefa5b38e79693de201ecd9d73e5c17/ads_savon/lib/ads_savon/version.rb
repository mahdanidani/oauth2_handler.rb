# Module to keep the current library version.

module GoogleAdsSavon
  VERSION = "1.0.1"
end
