# Google Ads Savon

Google Ads Savon is a fork of [Savon 1](http://savonrb.com/version1/)
specific for use with the Google Ads Ruby Client Library.

Google Ads Savon is available through [Rubygems](http://rubygems.org/gems/google-ads-savon) and can be installed via:

    $ gem install google-ads-savon

This library is not intended for re-use outside of google-ads-common.

This is not an official Google product (experimental or otherwise), it is just code that happens to be owned by Google.

Documentation
-------------

Read about the original library at [savonrb.com/version1/](http://savonrb.com/version1/)
